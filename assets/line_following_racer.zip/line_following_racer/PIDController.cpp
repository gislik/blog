#include "PIDController.h"

PIDController::PIDController(double p, double i, double d, double s, double t)
  : Kp(p), Ki(i), Kd(d), setpoint(s), dt(t) {
  actual_position = 0.0;
  previous_error = 0.0;
  
  error = 0.0;
  integral = 0.0;
  derivative = 0.0;
}

double PIDController::output() {
  actual_position = read(); // taka lestur i stad 0
  error = setpoint - actual_position;
  integral += error*dt; 
  derivative = (error-previous_error)/dt;
  previous_error = error;
//  Serial.println(Kp*error + Ki*integral);
  return Kp*pow(error, 3) + Ki*integral + Kd*derivative;
}

double PIDController::control() {
  return -output();
}

double PIDController::read() const {
  return 0.0;
}

