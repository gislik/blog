#include "Car.h"

Car::Car() 
  : lfpin(LEFTFORWARD),
    rfpin(RIGHTFORWARD),
    lbpin(LEFTBACKWARD),
    rbpin(RIGHTBACKWARD),
    lpin_m(1.0),
    rpin_m(1.0) {}

Car::Car(int lfp, int rfp, int lbp, int rbp) 
  : lfpin(lfp), rfpin(rfp), lbpin(lbp), rbpin(rbp),
    lpin_m(1.0),
    rpin_m(1.0) {}

boolean Car::drive(int direction, int speed100) {
  static int olddirection = 0;
  static int oldspeed100 = 0;
  int lf = 0, rf = 0, lb = 0, rb = 0;

  /*
  if (olddirection == direction && oldspeed100 == speed100)
    return true;
  */

  if (speed100 < 0 || speed100 > 100)
    return false;
  else
    oldspeed100 = speed100;
  
  speed = mapSpeed(speed100);
    
  // reducer is a number [-1,1] to reduce the power to either motor
  double reducer = cos(direction * PI / 180.0);
  // do this instead of comparing sin(direction_rad) because
  // integer math is much faster than double math
  if (0 <= direction && direction <= 180)  // turn right
    if (direction < 90) {
      lf = speed;
      rf = speed * reducer;
    } else {
      lf = speed;
      rb = speed * -reducer;
    }    
  else if (-180 <= direction && direction <= 0)  // turn left
    if (direction > -90) { 
      rf = speed;
      lf = speed * reducer;
    } else {
      rf = speed;
      lb = speed * -reducer; 
    }
  else
    return false;

  writePins(lf, rf, lb, rb);
  olddirection = direction;
  return true;
}

void Car::forward(int speed100) {
  speed = mapSpeed(speed100);
  writePins(speed, speed, 0, 0);
}

void Car::reverse(int speed100) {
  speed = mapSpeed(speed100);
  writePins(0, 0, speed, speed); 
}

void Car::stop() {
  speed = 0;
  writePins(0, 0, 0, 0);
}


void Car::writePins(int lf, int rf, int lb, int rb) const {
  analogWrite(lfpin, (int) (lpin_m*lf));
  analogWrite(rfpin, (int) (lpin_m*rf));
  analogWrite(lbpin, lb);
  analogWrite(rbpin, rb);
}

int Car::mapSpeed(int speed100) const {
  return map(speed100, 0, 100, 0, 255);
}
