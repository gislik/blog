#ifndef CARCONTROLLER_H
#define CARCONTROLLER_H
#include <WProgram.h>
#include "PIDController.h"

class CarController : public PIDController {
 protected:

 public:
  CarController();
  CarController(double, double, double, double, double);    
  byte readSensors() const;
  double read() const;
};
#endif
