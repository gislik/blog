#include "CarController.h"

CarController::CarController() 
  : PIDController(3.8, 0, 0.0, 0.0, 0.005) {
//  : PIDController(1, 0, 0, 0.0, 0.005) {
    pinMode(0, INPUT);
    pinMode(1, INPUT);
  }


CarController::CarController(double p, double i, double d, double s, double t)
  : PIDController::PIDController(p,i,d,s,t) {}

double CarController::read() const {  
  double result = 0.0;
  int count1s = 0;
  int temp = 0;
  byte sensors = readSensors();
  if (sensors == B01111110)
    return 0.0;
  for (int i = -4, multiplier = i; i < 4; i++) { // sensors stored LSB
    if (i == 0) multiplier++;
    temp = (sensors & (1 << (3-i))) >> (3-i);
    result += multiplier++*temp;
    if (temp == 1)
      count1s++;
  }
  return result/max(count1s, 1);
}

byte CarController::readSensors() const {
  byte result = 0;
  byte value = 0;
  for (int i = 0; i < 6; i++) {
    int reading = analogRead(i);
    if (reading < 50) value = B0; // hvitt
    else value = B1; // svart
    result |= value << i+1;
  }  
//  result |= digitalRead(0) << 6;
//  result |= digitalRead(1) << 7;
  
  return result;
}
