#ifndef PIDCONTROLLER_H
#define PIDCONTROLLER_H

#include <WProgram.h>

class PIDController {
 protected:
  double actual_position;
  double previous_error;
    
  double error;
  double integral;
  double derivative;
  const double Kp;
  const double Ki;
  const double Kd;
  const double dt; 
  const double setpoint;
  virtual double read() const;

 public:
  PIDController(double, double, double, double, double);
  /* calculates the output, i.e. the error after haveing read() */
  virtual double output();
  /* gives the action to take, i.e. returns -output() */
  double control();
};
#endif
