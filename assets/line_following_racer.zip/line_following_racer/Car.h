/*
 
 */

#ifndef CAR_H
#define CAR_H
#include "WProgram.h"

// define motor driver pins
// The PWM outputs generated on pins 5 and 6 will have 
// higher-than-expected duty cycles
const int LEFTFORWARD   =  3;
const int RIGHTFORWARD  =  9;
const int LEFTBACKWARD  = 10;
const int RIGHTBACKWARD = 11;

class Car {
 private:
 protected:
  int speed;                       // [0, 255]
  int lfpin, rfpin, lbpin, rbpin;  // pins for motor controller
  double lpin_m, rpin_m;           // [0.0, 1.0] multiplier constant for left and right pin
  /* writes to lfpin, rfpin, lbpin, rbpin the respective values */
  int mapSpeed(int) const;         // [0, 100] -> [0, 255]
 public:
  /* lfpin, rfpin, lbpin, rbpin */
  Car(int, int, int, int);
  /* initializes the car with the constants defined above */
  Car();
  /* drive takes two parameters:
     - direction [-180, 180] with 0 being straight ahead
     - speed [0,100] a percentage of the power of the motors
  
     returns true if direction and speed are in range, false otherwise
  */
  boolean drive(int, int);
  /* drives the car forward, in direction 0, at the speed given */
  void forward(int);
  /* drives the car backwards, in direction -180, at the speed given */
  void reverse(int);
  /* stops the car */
  void stop();
  void writePins(int, int, int, int) const;
  
};
#endif
